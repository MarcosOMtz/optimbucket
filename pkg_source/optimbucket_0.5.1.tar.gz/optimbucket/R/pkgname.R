#' Create, Optimize, Bucket and Manipulate ROC Curves in a Flash
#'
#' \code{Optimbucket} allows you to create ROC curves very easily. It has
#' dedicated functions for optimizing and manipulating them, all while handling
#' special values. You can also transform the variables to the new bucketing's
#' scale, check on their performance, print crucial information about them and
#' plot the most important aspects of any ROC curve in just a few lines of code.
#' As a bonus, there are also batch functions to deal with the case when there
#' are many variables.
#'
#' Enjoy!
"_PACKAGE"
